const pool = require('../../dbConn.js'); 

var get_sessionbyid = function(req , res){                      // defining get_sessionbyid Callback Function.
    pool.query("select * from session where s_id = $1" ,        // getting details of the session whose Id
    [req.params.session_id] ,                                   // is provided by the user.
    (err, result)=>{                                              
        if(err){                                                
            throw err;
        }
        else{
            res.send(result.rows[0]);                           
            res.end();                                          
        }
    });
}

module.exports = get_sessionbyid;