const pool = require('../../dbConn');

get_role = (req, res) => {
    pool.query("select * from get_role($1)",                // Getting the details : 
    [req.params.email] , (err , result) => {                // (user_id , full_name , role , active_status , designation)
        if(err){                                            // from the database function (get_role('email_id')) by passing the email id
            throw err;                                      // of the user.
        }                                                   
        else{
            res.send(result.rows[0]);
            res.end();               
        }
    });
};

module.exports = get_role;