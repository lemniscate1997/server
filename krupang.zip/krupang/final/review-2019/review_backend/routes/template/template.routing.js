const template_insert = require('./template_insert.action.js');
const express = require('express');
const router = express.Router();

router.post('/', template_insert);

module.exports = router;