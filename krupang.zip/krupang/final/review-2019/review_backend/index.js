const express = require('express');
const bodyParser = require('body-parser');
const login = require('./routes/login/login.routing');
const Session = require('./routes/session/session.routing');
const template = require('./routes/template/template.routing');
const {templateModel,stmModel,userDetailsModel,sessionModel,designationModel} = require('./dbConn');
const app = express();

app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.use("/login", login);
app.use("/session", Session);
app.use("/template", template);


app.use("/testing",(req,res,next)=>{
  userDetailsModel.findAll({
    where: {type:'ROLE_SADMIN'},
      include: [{
        model: designationModel
        
       }]
    }).then((result)=>{
      res.status(200).json(result);
    });
});
app.use("/testing1",(req,res,next)=>{
  templateModel.findAll({
    where: {t_id:6},
      include: [{
        model: userDetailsModel,
        as: 'createdBy',
        attributes:['user_id','first_name']
       }]
    }).then((result)=>{
      const respob = result.map(temp=>{

        return Object.assign(
          {},
          {
            t_id:temp.t_id,
            name:temp.t_name,
            description:temp.t_description,
            createdBy:temp.createdBy.first_name,
            createdAt:temp.created_at
          }
        );
        
      });
      res.status(200).json(respob);
    });
});





app.use((req, res, next) => {
  const error = new Error('Not Found!');
  error.status = 404;
  next(error);
});

app.use((error, req, res, next) => {
  res.status(error.status || 500);
  res.json({
    error: {
      message: error.message,
    },
  });
});

app.listen(3000);