
module.exports = function(sequelize, DataTypes) {
	return sequelize.define('session_template_mapping', {
		stm_id: {
			type: DataTypes.INTEGER,
			allowNull: false,
			primaryKey: true
		},
		stm_session_id: {
			type: DataTypes.INTEGER,
			allowNull: false
			// references: {
			// 	model: 'session',
			// 	key: 's_id'
			// }
		},
		stm_template_id: {
			type: DataTypes.INTEGER,
			allowNull: false
			// references: {
			// 	model: 'template',
			// 	key: 't_id'
			// }
		},
		stm_reviewee_id: {
			type: DataTypes.INTEGER,
			allowNull: false
			// references: {
			// 	model: 'system_user_detail',
			// 	key: 'user_id'
			// }
		},
		stm_reviewer_id: {
			type: DataTypes.INTEGER,
			allowNull: false
			// references: {
			// 	model: 'system_user_detail',
			// 	key: 'user_id'
			// }
		},
		stm_status: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: '1'
		},
		created_by: {
			type: DataTypes.INTEGER,
			allowNull: false
			// references: {
			// 	model: 'system_user_detail',
			// 	key: 'user_id'
			// }
		},
		created_at: {
			type: DataTypes.DATE,
			allowNull: false
		},
		modified_by: {
			type: DataTypes.INTEGER,
			allowNull: true
			// references: {
			// 	model: 'system_user_detail',
			// 	key: 'user_id'
			// }
		},
		modified_at: {
			type: DataTypes.DATE,
			allowNull: true
		}
	}, {
		tableName: 'session_template_mapping'
	});
};
