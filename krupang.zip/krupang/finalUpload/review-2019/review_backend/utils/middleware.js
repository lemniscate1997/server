let jwt = require('jsonwebtoken');
const config = require('./config');

let checkToken = (req, res, next) => {
    if(req.path ==='/login') next();
    console.log("hello");
    console.log(req.headers);
    
    let token = req.header('authorization');
    console.log(token);
    
    if (token.startsWith('Bearer ')) {
        token = token.slice(7, token.length);
    }

    if (token) {
        jwt.verify(token, config.secret, (err, decoded) => {
            if (err) {
   
                return res.json({
                    success: false,
                    message: 'Token is not valid'
                });
            } else {
                console.log(decoded);

                req.decoded = decoded;
                next();
            }
        });
    } else {
        return res.json({
            success: false,
            message: 'Auth token is not supplied'
        });
    }
};

module.exports = {
    checkToken: checkToken
}
