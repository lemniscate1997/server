module.exports = {
    secret: 'TheArgusOftDeveLopErNeSt' //key for encrypting value 
  };